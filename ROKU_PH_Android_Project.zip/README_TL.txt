ROKU PH Android project

Ano ang kasama:
- Android WebView app na nagbubukas ng https://rokuph.teyuto.tv
- Animated intro video na may custom sound effect (kung nailagay ang MP4 sa assets)
- GitHub Actions workflow para mag-build ng APK sa cloud

IMPORTANT:
Hindi pa kasama ang splash video sa project zip dahil kailangan itong kopyahin sa:
app/src/main/res/raw/roku_splash.mp4

Gamitin ang MP4 na ginawa natin:
ROKU_PH_deluxe_splash_unique_sound.mp4

Gabay gamit ang cellphone:
1. Gumawa o magbukas ng GitHub account.
2. Gumawa ng bagong repository na pangalan ay ROKU_PH_Android_Project.
3. I-upload ang laman ng ZIP na ito sa repository (huwag i-upload ang ZIP bilang iisang file; i-extract muna).
4. Gumawa ng folder: app/src/main/res/raw/
5. I-upload ang video doon at pangalanan itong roku_splash.mp4.
6. Pumunta sa tab na Actions, piliin ang "Build ROKU PH APK", tapos Run workflow.
7. Kapag successful, buksan ang completed run at i-download ang artifact na ROKU-PH-debug-apk.
8. I-extract ang artifact ZIP para makuha ang app-debug.apk.

Limitasyon:
- Ito ay debug APK para sa testing; hindi pa signed para sa Play Store.
- Sound playback ay depende sa device/audio settings.
- Dapat ma-test ang app sa aktuwal na Android device bago gamitin.
