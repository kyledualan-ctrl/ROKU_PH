package com.rokuph.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.VideoView;
import android.net.Uri;
import android.media.MediaPlayer;
import android.graphics.Color;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
    private FrameLayout root;
    private WebView webView;
    private VideoView splashVideo;
    private final Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(55, 8, 105));
        getWindow().setNavigationBarColor(Color.rgb(55, 8, 105));

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(55, 8, 105));
        setContentView(root);

        webView = new WebView(this);
        webView.setVisibility(View.INVISIBLE);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                // Keep the intro on screen until the intro timer ends.
            }
        });
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        webView.loadUrl("https://rokuph.teyuto.tv");

        splashVideo = new VideoView(this);
        splashVideo.setBackgroundColor(Color.rgb(55, 8, 105));
        root.addView(splashVideo, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        Uri videoUri = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.roku_splash);
        splashVideo.setVideoURI(videoUri);
        splashVideo.setOnPreparedListener(mp -> {
            mp.setVolume(1.0f, 1.0f);
            mp.setLooping(false);
            splashVideo.start();
        });
        splashVideo.setOnCompletionListener(mp -> showWebsite());
        splashVideo.setOnErrorListener((mp, what, extra) -> {
            showWebsite();
            return true;
        });

        // Fallback if video playback does not start or completion callback is missed.
        handler.postDelayed(this::showWebsite, 6500);
    }

    private boolean websiteShown = false;
    private void showWebsite() {
        if (websiteShown) return;
        websiteShown = true;
        if (splashVideo != null) splashVideo.setVisibility(View.GONE);
        if (webView != null) webView.setVisibility(View.VISIBLE);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
